window.onload = function () {
	
	const targetNode = document.getElementById("app");

	if (targetNode) {
	
		const config = { attributes: false, childList: true, subtree: true };
		
		const callback = (mutationList, observer) => {
			
			observer.disconnect();
			
			if (window.builderPgFunctionBinding) {
				
				const mainViewTxtArea = document.querySelector('[data-ace-id="mainview"]');
				if (mainViewTxtArea && !mainViewTxtArea.dataset.aceInit)
				{
					mainViewTxtArea.dataset.aceInit = true;
					
					// Ace editor location
					let aceDiv = document.createElement('div');
					mainViewTxtArea.parentNode.insertBefore(aceDiv, mainViewTxtArea);
					aceDiv.style.fontSize = '14px';
					aceDiv.className = mainViewTxtArea.className;
					mainViewTxtArea.style.display = 'none';
					
					// Ace editor initialization
					let aceEditor = ace.edit(aceDiv);
					aceEditor.session.setMode('ace/mode/pgsql');
					aceEditor.session.setUseSoftTabs(false);
					aceEditor.session.setValue(window.builderPgFunctionBinding.codeFunction);
					
					// Synchronization: vue -> ace (internal changes)
					const watcher= setInterval(function () {
						if (window.builderPgFunctionBinding.codeFunction != aceEditor.session.getValue()) {
							aceEditor.session.setValue(window.builderPgFunctionBinding.codeFunction);
						}
						
						if (mainViewTxtArea.parentNode === null) {
							aceEditor.container.remove();
							aceEditor.destroy();
							clearInterval(watcher);
							mainViewTxtArea.dataset.aceInit = false;
						}
					}, 500);
					
					// Synchronization: ace -> vue (external changes)
					aceEditor.session.on('change', function() {
						window.builderPgFunctionBinding.codeFunction = aceEditor.session.getValue();
					});
					
					// Placeholders propagation
					aceEditor.on('click', function() {           
						if (window.builderPgFunctionBinding.entityId) {
							mainViewTxtArea.selectionStart = aceEditor.session.doc.positionToIndex(aceEditor.getCursorPosition(), 0);
							mainViewTxtArea.selectionEnd = mainViewTxtArea.selectionStart;
							window.builderPgFunctionBinding.insertEntity({target: mainViewTxtArea}); //click emulation
						}
					});
				}
				
				const preViewTxtArea = document.querySelector('[data-ace-id="preview"]');
				if (preViewTxtArea && !preViewTxtArea.dataset.aceInit)
				{
					preViewTxtArea.dataset.aceInit = true;
					
					// Ace editor location
					let aceDiv = document.createElement('div');
					preViewTxtArea.parentNode.insertBefore(aceDiv, preViewTxtArea);
					aceDiv.style.fontSize = '14px';
					aceDiv.className = preViewTxtArea.className;
					preViewTxtArea.style.display = 'none';
					
					// Ace editor initialization
					let aceEditor = ace.edit(aceDiv);
					aceEditor.setReadOnly(true);
					aceEditor.session.setMode('ace/mode/pgsql');
					aceEditor.session.setUseSoftTabs(false);
					aceEditor.session.setValue(window.builderPgFunctionBinding.preview);
					
					// Synchronization: vue -> ace (internal changes)
					const watcher= setInterval(function () {
						if (preViewTxtArea.parentNode === null) {
							aceEditor.container.remove();
							aceEditor.destroy();
							clearInterval(watcher);
							preViewTxtArea.dataset.aceInit = false;
						}
					}, 500);
				}
			}
			
			observer.observe(targetNode, config);
		};
		
		const observer = new MutationObserver(callback);
		observer.observe(targetNode, config);
	
	}
};

